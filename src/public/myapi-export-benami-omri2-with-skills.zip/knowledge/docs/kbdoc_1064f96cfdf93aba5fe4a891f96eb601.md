CONF_DEVICE_IP_ADDR=192.168.48.50 [כתובת של ה switcher] 
CONF_PHONE_ID=0000 
CONF_DEVICE_ID=6c005f 
CONF_DEVICE_PASSWORD=12345678 
CONF_THROTTLE=5.0 

צילומי מסך : 
 
 
 
 
 
 

 
 
 
 
 
 

בסיום לוחצים על    
ומוודאים שהוא למעלה:  
 
 
ב configuration.yaml רושמים לפי המדריך  של דימה : 
https://github.com/dmatik/homeassistant-config/wiki/Switcher-integration-using-WebAPI 
 
 
דוגמאות:  
 
הכתובת ip היא של מכונת ה  hassio  (192.168.48.35 ) 

 
 
  
  

בהוספת כרטיסיית entities  רגילה אפשר לראות:  
 
 
 
בהצלחה!
