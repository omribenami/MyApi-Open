# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:**
- **What to call them:**
- **Pronouns:** _(optional)_
- **Timezone:**
- **Notes:**

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.

- **Name**: Omri Ben Ami
- **Pronouns:**: _(optional)_
- **Location**: Leander, Texas, US
- **Timezone**: America/Chicago
- **Occupation**: CEO MyApi
- **GitHub**: github.com/omribenami
- **Website**: https://MyApiai.com
- **Bio**: CEO of MyApi | US Team Lead, ID.Buzz Project @ Mobileye
I build systems that talk to each other. Whether it’s leading the US integration of autonomous vans for Mobileye or developing the infrastructure at MyApi, my focus is always on SW/HW synergy. I’m a lifelong technologist obsessed with AI, 3D printing, and Home Assistant automation. If it can be integrated, optimized, or automated, I’m working on it.

- **Email**: benami.omri@gmail.com

- **AvatarUrl**: https://www.myapiai.com/

- **avatarUrl**: https://www.myapiai.com/
